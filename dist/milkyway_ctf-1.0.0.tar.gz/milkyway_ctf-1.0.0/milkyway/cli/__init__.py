"""MilkyWay CLI."""
