"""MilkyWay planets."""
