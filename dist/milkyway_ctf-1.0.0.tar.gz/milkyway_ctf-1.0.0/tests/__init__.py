"""MilkyWay test suite."""
